/* -----------------------------------------------------------------------------
  Filename:    sio_par.h
  Description: Toolversion: 00.00.00.01.60.08.59.00.00.00
               
               Serial Number: CBD1600859
               Customer Info: SPAL Automotive srl
                              Package: LIN_SLP2
                              Micro: NXP S9S12GN32F1MLC
                              Compiler: Metrowerks HC12 5.1
               
               
               Generator Fwk   : GENy 
               Generator Module: DrvLin__baseSci
               
               Configuration   : C:\Users\rossia\Desktop\KBL265P 3G RC6\Geny\GENy_2602_Nessim.gny
               
               ECU: 
                       TargetSystem: Hw_Mcs12xCpu
                       Compiler:     Metrowerks
                       Derivates:    MCS12G
               
               Channel "SPAL_LIN":
                       Databasefile: C:\Users\rossia\Desktop\KBL265P 3G RC5\Database\GB_129_ECM_LIN1_CFM1_J2602_unchanged.ldf
                       Bussystem:    LIN
                       Node:         CFM1

 ----------------------------------------------------------------------------- */
/* -----------------------------------------------------------------------------
  C O P Y R I G H T
 -------------------------------------------------------------------------------
  Copyright (c) 2001-2015 by Vector Informatik GmbH. All rights reserved.
 
  This software is copyright protected and proprietary to Vector Informatik 
  GmbH.
  
  Vector Informatik GmbH grants to you only those rights as set out in the 
  license conditions.
  
  All other rights remain with Vector Informatik GmbH.
 -------------------------------------------------------------------------------
 ----------------------------------------------------------------------------- */

#if !defined(__SIO_PAR_H__)
#define __SIO_PAR_H__

#define kSioBaudrate                         10417
#define kSioCalcBaudrate                     10416

#define kSioSynchBreakByte                   0x00

#define kLinFrequency                        20000
#define kChannel_UART0                       0
#define kSioTIMPrescalerShiftValue           2
#define kSioSBPulseMinLength                 0x14A0
#define kSioPulseNominalLength               0x01
#define kSioPulseMinLength                   0x01
#define kSioPulseMaxLength                   0x01
#define kLinRegHc12ScH_Baudrate              0x00
#define kLinRegHc12ScL_Baudrate              0x78
#define kTimerChannel                        3
#define kSioNumberOfBaudrates                0


/* begin Fileversion check */
#ifndef SKIP_MAGIC_NUMBER
#ifdef MAGIC_NUMBER
  #if MAGIC_NUMBER != 239564544
      #error "The magic number of the generated file <C:\Users\rossia\Desktop\KBL265P 3G RC6\Sources\GEN_data\sio_par.h> is different. Please check time and date of generated files!"
  #endif
#else
  #define MAGIC_NUMBER 239564544
#endif  /* MAGIC_NUMBER */
#endif  /* SKIP_MAGIC_NUMBER */

/* end Fileversion check */

#endif /* __SIO_PAR_H__ */
