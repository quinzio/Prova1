/* -----------------------------------------------------------------------------
  Filename:    lin_par.h
  Description: Toolversion: 00.00.00.01.60.08.59.00.00.00
               
               Serial Number: CBD1600859
               Customer Info: SPAL Automotive srl
                              Package: LIN_SLP2
                              Micro: NXP S9S12GN32F1MLC
                              Compiler: Metrowerks HC12 5.1
               
               
               Generator Fwk   : GENy 
               Generator Module: DrvLin__base
               
               Configuration   : C:\Users\rossia\Desktop\KBL265P 3G RC6\Geny\GENy_2602_Nessim.gny
               
               ECU: 
                       TargetSystem: Hw_Mcs12xCpu
                       Compiler:     Metrowerks
                       Derivates:    MCS12G
               
               Channel "SPAL_LIN":
                       Databasefile: C:\Users\rossia\Desktop\KBL265P 3G RC5\Database\GB_129_ECM_LIN1_CFM1_J2602_unchanged.ldf
                       Bussystem:    LIN
                       Node:         CFM1

 ----------------------------------------------------------------------------- */
/* -----------------------------------------------------------------------------
  C O P Y R I G H T
 -------------------------------------------------------------------------------
  Copyright (c) 2001-2015 by Vector Informatik GmbH. All rights reserved.
 
  This software is copyright protected and proprietary to Vector Informatik 
  GmbH.
  
  Vector Informatik GmbH grants to you only those rights as set out in the 
  license conditions.
  
  All other rights remain with Vector Informatik GmbH.
 -------------------------------------------------------------------------------
 ----------------------------------------------------------------------------- */

#if !defined(__LIN_PAR_H__)
#define __LIN_PAR_H__

/* -----------------------------------------------------------------------------
    &&&~ MISRA definitions
 ----------------------------------------------------------------------------- */

/* PRQA S 3458 EOF *//* MD_CBD_19.4 */


/* -----------------------------------------------------------------------------
    &&&~ Timeout handling
 ----------------------------------------------------------------------------- */

#define kLinFastTimeoutTaskCycle             8000
#define kLinSlowTimeoutTaskCycle             8
#define kLinTimeBaseHighRes                  1000


/* -----------------------------------------------------------------------------
    &&&~ Message Callback functions
 ----------------------------------------------------------------------------- */

/* return values used by precopy and pretransmit functions */
#define kLinNoCopyData                       0x00U
#define kLinCopyData                         0x01U


/* -----------------------------------------------------------------------------
    &&&~ Access to confirmation flags
 ----------------------------------------------------------------------------- */

#define ECM_LIN1_CFM1_RSP_MSG_conf_b         (uLinMsgConfirmationFlags.w[0].b0)
#define l_flg_tst_ECM_LIN1_CFM1_RSP_MSG()    (ECM_LIN1_CFM1_RSP_MSG_conf_b != 0)
#define l_flg_clr_ECM_LIN1_CFM1_RSP_MSG()    (ECM_LIN1_CFM1_RSP_MSG_conf_b = 0)
#define SlaveResp_conf_b                     (uLinMsgConfirmationFlags.w[0].b1)
#define l_flg_tst_SlaveResp()                (SlaveResp_conf_b != 0)
#define l_flg_clr_SlaveResp()                (SlaveResp_conf_b = 0)


/* -----------------------------------------------------------------------------
    &&&~ Access to indication flags
 ----------------------------------------------------------------------------- */

#define ECM_LIN1_CFM1_Cmd_MSG_ind_b          (uLinMsgIndicationFlags.w[0].b0)
#define l_flg_tst_ECM_LIN1_CFM1_Cmd_MSG()    (ECM_LIN1_CFM1_Cmd_MSG_ind_b != 0)
#define l_flg_clr_ECM_LIN1_CFM1_Cmd_MSG()    (ECM_LIN1_CFM1_Cmd_MSG_ind_b = 0)
#define MasterReq_ind_b                      (uLinMsgIndicationFlags.w[0].b1)
#define l_flg_tst_MasterReq()                (MasterReq_ind_b != 0)
#define l_flg_clr_MasterReq()                (MasterReq_ind_b = 0)


/* -----------------------------------------------------------------------------
    &&&~ Macro Access to signals
 ----------------------------------------------------------------------------- */

#define _s_PrplCoolFn1SpdCmd                 (ECM_LIN1_CFM1_Cmd_MSG.ECM_LIN1_CFM1_Cmd_MSG.PrplCoolFn1SpdCmd)
#define _s_PrplCoolFn1CommErr                (ECM_LIN1_CFM1_RSP_MSG.ECM_LIN1_CFM1_RSP_MSG.PrplCoolFn1CommErr)
#define _s_PrplCoolFn1_ARC                   (ECM_LIN1_CFM1_RSP_MSG.ECM_LIN1_CFM1_RSP_MSG.PrplCoolFn1_ARC)
#define _s_PrplCoolFn1IntlOplFltPrsnt        (ECM_LIN1_CFM1_RSP_MSG.ECM_LIN1_CFM1_RSP_MSG.PrplCoolFn1IntlOplFltPrsnt)
#define _s_PrplCoolFn1PwrSysFltPrsnt         (ECM_LIN1_CFM1_RSP_MSG.ECM_LIN1_CFM1_RSP_MSG.PrplCoolFn1PwrSysFltPrsnt)
#define _s_PrplCoolFn1OvrTempFltPrsnt        (ECM_LIN1_CFM1_RSP_MSG.ECM_LIN1_CFM1_RSP_MSG.PrplCoolFn1OvrTempFltPrsnt)
#define _s_PrplCoolFn1SpdActl_0              (ECM_LIN1_CFM1_RSP_MSG.ECM_LIN1_CFM1_RSP_MSG.PrplCoolFn1SpdActl_0)
#define _s_PrplCoolFn1SpdActl_1              (ECM_LIN1_CFM1_RSP_MSG.ECM_LIN1_CFM1_RSP_MSG.PrplCoolFn1SpdActl_1)
#define _s_PrplCoolFn1ExtrnMtrOpnCkt         (ECM_LIN1_CFM1_RSP_MSG.ECM_LIN1_CFM1_RSP_MSG.PrplCoolFn1ExtrnMtrOpnCkt)
#define _s_PrplCoolFn1ExtrnMtrShrtPwr        (ECM_LIN1_CFM1_RSP_MSG.ECM_LIN1_CFM1_RSP_MSG.PrplCoolFn1ExtrnMtrShrtPwr)
#define _s_PrplCoolFn1ExtrnMtrShrtGnd        (ECM_LIN1_CFM1_RSP_MSG.ECM_LIN1_CFM1_RSP_MSG.PrplCoolFn1ExtrnMtrShrtGnd)


/* -----------------------------------------------------------------------------
    &&&~ Access to signals
 ----------------------------------------------------------------------------- */

#define l_u8_rd_PrplCoolFn1SpdCmd()          _s_PrplCoolFn1SpdCmd
#define l_u8_wr_PrplCoolFn1SpdCmd(a) \
{ \
  LinStartRxBitSignalReadSync(); \
  _s_PrplCoolFn1SpdCmd = ((vuint8) (((vuint8) (a)) & 0xFF)); \
  LinEndRxBitSignalReadSync(); \
}
#define l_bool_rd_PrplCoolFn1CommErr()       _s_PrplCoolFn1CommErr
#define l_bool_wr_PrplCoolFn1CommErr(a) \
{ \
  LinStartTxBitSignalReadSync(); \
  _s_PrplCoolFn1CommErr = ((vuint8) (((vuint8) (a)) & 0x01)); \
  LinEndTxBitSignalReadSync(); \
}
#define l_u8_rd_PrplCoolFn1_ARC()            _s_PrplCoolFn1_ARC
#define l_u8_wr_PrplCoolFn1_ARC(a) \
{ \
  LinStartTxBitSignalReadSync(); \
  _s_PrplCoolFn1_ARC = ((vuint8) (((vuint8) (a)) & 0x03)); \
  LinEndTxBitSignalReadSync(); \
}
#define l_bool_rd_PrplCoolFn1IntlOplFltPrsnt() _s_PrplCoolFn1IntlOplFltPrsnt
#define l_bool_wr_PrplCoolFn1IntlOplFltPrsnt(a) \
{ \
  LinStartTxBitSignalReadSync(); \
  _s_PrplCoolFn1IntlOplFltPrsnt = ((vuint8) (((vuint8) (a)) & 0x01)); \
  LinEndTxBitSignalReadSync(); \
}
#define l_bool_rd_PrplCoolFn1PwrSysFltPrsnt() _s_PrplCoolFn1PwrSysFltPrsnt
#define l_bool_wr_PrplCoolFn1PwrSysFltPrsnt(a) \
{ \
  LinStartTxBitSignalReadSync(); \
  _s_PrplCoolFn1PwrSysFltPrsnt = ((vuint8) (((vuint8) (a)) & 0x01)); \
  LinEndTxBitSignalReadSync(); \
}
#define l_bool_rd_PrplCoolFn1OvrTempFltPrsnt() _s_PrplCoolFn1OvrTempFltPrsnt
#define l_bool_wr_PrplCoolFn1OvrTempFltPrsnt(a) \
{ \
  LinStartTxBitSignalReadSync(); \
  _s_PrplCoolFn1OvrTempFltPrsnt = ((vuint8) (((vuint8) (a)) & 0x01)); \
  LinEndTxBitSignalReadSync(); \
}
#define l_u16_rd_PrplCoolFn1SpdActl()        ((vuint16) (((vuint16) (_s_PrplCoolFn1SpdActl_1) << 8) | ((vuint16) (_s_PrplCoolFn1SpdActl_0))))
#define l_u16_wr_PrplCoolFn1SpdActl(a) \
{ \
  { \
    LinStartTxSignalWriteSync(); \
    _s_PrplCoolFn1SpdActl_0 = ((vuint8) (((vuint16) (a)) & 0xFF)); \
    _s_PrplCoolFn1SpdActl_1 = ((vuint8) ((((vuint16) (a)) & 0x0100) >> 8)); \
    LinEndTxSignalWriteSync(); \
  } \
}
#define l_u8_rd_PrplCoolFn1ExtrnMtrOpnCkt()  _s_PrplCoolFn1ExtrnMtrOpnCkt
#define l_u8_wr_PrplCoolFn1ExtrnMtrOpnCkt(a) \
{ \
  LinStartTxBitSignalReadSync(); \
  _s_PrplCoolFn1ExtrnMtrOpnCkt = ((vuint8) (((vuint8) (a)) & 0x03)); \
  LinEndTxBitSignalReadSync(); \
}
#define l_u8_rd_PrplCoolFn1ExtrnMtrShrtPwr() _s_PrplCoolFn1ExtrnMtrShrtPwr
#define l_u8_wr_PrplCoolFn1ExtrnMtrShrtPwr(a) \
{ \
  LinStartTxBitSignalReadSync(); \
  _s_PrplCoolFn1ExtrnMtrShrtPwr = ((vuint8) (((vuint8) (a)) & 0x03)); \
  LinEndTxBitSignalReadSync(); \
}
#define l_u8_rd_PrplCoolFn1ExtrnMtrShrtGnd() _s_PrplCoolFn1ExtrnMtrShrtGnd
#define l_u8_wr_PrplCoolFn1ExtrnMtrShrtGnd(a) \
{ \
  LinStartTxBitSignalReadSync(); \
  _s_PrplCoolFn1ExtrnMtrShrtGnd = ((vuint8) (((vuint8) (a)) & 0x03)); \
  LinEndTxBitSignalReadSync(); \
}


/* -----------------------------------------------------------------------------
    &&&~ Access to data bytes of Rx messages
 ----------------------------------------------------------------------------- */

/* ID: 0x2c, Handle: 0, Name: ECM_LIN1_CFM1_Cmd_MSG */
#define c1_ECM_LIN1_CFM1_Cmd_MSG_c           (ECM_LIN1_CFM1_Cmd_MSG._c[0])



/* -----------------------------------------------------------------------------
    &&&~ Access to data bytes of Tx messages
 ----------------------------------------------------------------------------- */

/* ID: 0x2d, Handle: 1, Name: ECM_LIN1_CFM1_RSP_MSG */
#define c1_ECM_LIN1_CFM1_RSP_MSG_c           (ECM_LIN1_CFM1_RSP_MSG._c[0])
#define c2_ECM_LIN1_CFM1_RSP_MSG_c           (ECM_LIN1_CFM1_RSP_MSG._c[1])
#define c3_ECM_LIN1_CFM1_RSP_MSG_c           (ECM_LIN1_CFM1_RSP_MSG._c[2])



/* -----------------------------------------------------------------------------
    &&&~ Prototypes of Precopy Functions
 ----------------------------------------------------------------------------- */



/* -----------------------------------------------------------------------------
    &&&~ Prototypes of Indication Functions
 ----------------------------------------------------------------------------- */



/* -----------------------------------------------------------------------------
    &&&~ Prototypes of Confirmation Functions
 ----------------------------------------------------------------------------- */

extern void ApplLinConf_RESP_MSG(tLinFrameHandleType vMsgHandle);



/* -----------------------------------------------------------------------------
    &&&~ Prototypes of Pretransmit Functions
 ----------------------------------------------------------------------------- */

extern vuint8 ApplLinPreTransmit_RESP_MSG(vuint8* txBuffer);



/* -----------------------------------------------------------------------------
    &&&~ Message Handles
 ----------------------------------------------------------------------------- */

#define LinRxECM_LIN1_CFM1_Cmd_MSG           0
#define LinTxECM_LIN1_CFM1_RSP_MSG           1
#define LinRxMasterReq                       2
#define LinTxSlaveResp                       3


/* -----------------------------------------------------------------------------
    &&&~ Declaration of objects provided by lin_par.c
 ----------------------------------------------------------------------------- */



/* -----------------------------------------------------------------------------
    &&&~ Name defines for LIN channel
 ----------------------------------------------------------------------------- */

#ifndef SPAL_LIN
#define SPAL_LIN                             0
#endif




/* begin Fileversion check */
#ifndef SKIP_MAGIC_NUMBER
#ifdef MAGIC_NUMBER
  #if MAGIC_NUMBER != 239564544
      #error "The magic number of the generated file <C:\Users\rossia\Desktop\KBL265P 3G RC6\Sources\GEN_data\lin_par.h> is different. Please check time and date of generated files!"
  #endif
#else
  #define MAGIC_NUMBER 239564544
#endif  /* MAGIC_NUMBER */
#endif  /* SKIP_MAGIC_NUMBER */

/* end Fileversion check */

#endif /* __LIN_PAR_H__ */
