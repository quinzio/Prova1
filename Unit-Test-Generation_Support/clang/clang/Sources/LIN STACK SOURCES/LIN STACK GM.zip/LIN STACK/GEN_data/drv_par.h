/* -----------------------------------------------------------------------------
  Filename:    drv_par.h
  Description: Toolversion: 00.00.00.01.60.08.59.00.00.00
               
               Serial Number: CBD1600859
               Customer Info: SPAL Automotive srl
                              Package: LIN_SLP2
                              Micro: NXP S9S12GN32F1MLC
                              Compiler: Metrowerks HC12 5.1
               
               
               Generator Fwk   : GENy 
               Generator Module: GenTool_GenyDriverBase
               
               Configuration   : C:\Users\rossia\Desktop\KBL265P 3G RC6\Geny\GENy_2602_Nessim.gny
               
               ECU: 
                       TargetSystem: Hw_Mcs12xCpu
                       Compiler:     Metrowerks
                       Derivates:    MCS12G
               
               Channel "SPAL_LIN":
                       Databasefile: C:\Users\rossia\Desktop\KBL265P 3G RC5\Database\GB_129_ECM_LIN1_CFM1_J2602_unchanged.ldf
                       Bussystem:    LIN
                       Node:         CFM1

 ----------------------------------------------------------------------------- */
/* -----------------------------------------------------------------------------
  C O P Y R I G H T
 -------------------------------------------------------------------------------
  Copyright (c) 2001-2015 by Vector Informatik GmbH. All rights reserved.
 
  This software is copyright protected and proprietary to Vector Informatik 
  GmbH.
  
  Vector Informatik GmbH grants to you only those rights as set out in the 
  license conditions.
  
  All other rights remain with Vector Informatik GmbH.
 -------------------------------------------------------------------------------
 ----------------------------------------------------------------------------- */

#if !defined(__DRV_PAR_H__)
#define __DRV_PAR_H__

/* -----------------------------------------------------------------------------
    &&&~ Signal Structures
 ----------------------------------------------------------------------------- */

typedef struct _c_ECM_LIN1_CFM1_Cmd_MSG_msgTypeTag
{
  vbittype PrplCoolFn1SpdCmd : 8;
  vbittype unused0 : 8;
} _c_ECM_LIN1_CFM1_Cmd_MSG_msgType;
typedef struct _c_ECM_LIN1_CFM1_RSP_MSG_msgTypeTag
{
  vbittype PrplCoolFn1CommErr : 1;
  vbittype PrplCoolFn1_ARC : 2;
  vbittype PrplCoolFn1IntlOplFltPrsnt : 1;
  vbittype PrplCoolFn1PwrSysFltPrsnt : 1;
  vbittype PrplCoolFn1OvrTempFltPrsnt : 1;
  vbittype unused0 : 2;
  vbittype PrplCoolFn1SpdActl_0 : 8;
  vbittype PrplCoolFn1SpdActl_1 : 1;
  vbittype PrplCoolFn1ExtrnMtrOpnCkt : 2;
  vbittype PrplCoolFn1ExtrnMtrShrtPwr : 2;
  vbittype PrplCoolFn1ExtrnMtrShrtGnd : 2;
  vbittype unused1 : 1;
  vbittype unused2 : 8;
} _c_ECM_LIN1_CFM1_RSP_MSG_msgType;


/* -----------------------------------------------------------------------------
    &&&~ Signal value names
 ----------------------------------------------------------------------------- */



/* -----------------------------------------------------------------------------
    &&&~ Message Unions
 ----------------------------------------------------------------------------- */

typedef union _c_ECM_LIN1_CFM1_Cmd_MSG_bufTag
{
  vuint16 _w[1];
  vuint8 _c[2];
  _c_ECM_LIN1_CFM1_Cmd_MSG_msgType ECM_LIN1_CFM1_Cmd_MSG;
} _c_ECM_LIN1_CFM1_Cmd_MSG_buf;
typedef union _c_ECM_LIN1_CFM1_RSP_MSG_bufTag
{
  vuint16 _w[2];
  vuint8 _c[4];
  _c_ECM_LIN1_CFM1_RSP_MSG_msgType ECM_LIN1_CFM1_RSP_MSG;
} _c_ECM_LIN1_CFM1_RSP_MSG_buf;


/* -----------------------------------------------------------------------------
    &&&~ Message Buffers
 ----------------------------------------------------------------------------- */

/* RAM CATEGORY 2 START */
V_MEMRAM0 extern  V_MEMRAM1 _c_ECM_LIN1_CFM1_Cmd_MSG_buf V_MEMRAM2 ECM_LIN1_CFM1_Cmd_MSG;
/* RAM CATEGORY 2 END */

/* RAM CATEGORY 2 START */
V_MEMRAM0 extern  V_MEMRAM1 _c_ECM_LIN1_CFM1_RSP_MSG_buf V_MEMRAM2 ECM_LIN1_CFM1_RSP_MSG;
/* RAM CATEGORY 2 END */

/* RAM CATEGORY 2 START */
/* RAM CATEGORY 2 END */

/* RAM CATEGORY 2 START */
/* RAM CATEGORY 2 END */






/* begin Fileversion check */
#ifndef SKIP_MAGIC_NUMBER
#ifdef MAGIC_NUMBER
  #if MAGIC_NUMBER != 239564544
      #error "The magic number of the generated file <C:\Users\rossia\Desktop\KBL265P 3G RC6\Sources\GEN_data\drv_par.h> is different. Please check time and date of generated files!"
  #endif
#else
  #define MAGIC_NUMBER 239564544
#endif  /* MAGIC_NUMBER */
#endif  /* SKIP_MAGIC_NUMBER */

/* end Fileversion check */

#endif /* __DRV_PAR_H__ */
